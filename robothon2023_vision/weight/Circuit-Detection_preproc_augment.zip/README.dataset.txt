# Circuit-Detection > preproc - augment
https://universe.roboflow.com/national-research-council-of-italy/circuit-detection

Provided by a Roboflow user
License: CC BY 4.0

