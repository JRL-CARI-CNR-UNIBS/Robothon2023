# Circuit-Detection > 2023-05-03 8:44pm
https://universe.roboflow.com/national-research-council-of-italy/circuit-detection

Provided by a Roboflow user
License: CC BY 4.0

